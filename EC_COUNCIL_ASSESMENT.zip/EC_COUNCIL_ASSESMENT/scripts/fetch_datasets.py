#!/usr/bin/env python3
"""Fetch optional public CTI datasets into data/raw/.

The app runs from data/threat_intel_seed.json by default. This script records the
internet dataset choices used for the assessment and gives a path to refresh
from public sources when network access and any required credentials are present.
"""

from __future__ import annotations

import argparse
import json
import os
import time
import urllib.error
import urllib.request
from pathlib import Path


SOURCES = {
    "mitre_attack_enterprise": "https://raw.githubusercontent.com/mitre-attack/attack-stix-data/master/enterprise-attack/enterprise-attack.json",
    "cisa_kev": "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json",
    "nvd_cve_2022_26134": "https://services.nvd.nist.gov/rest/json/cves/2.0?cveId=CVE-2022-26134",
}


def fetch(url: str, destination: Path, headers: dict[str, str] | None = None) -> None:
    request = urllib.request.Request(url, headers=headers or {"User-Agent": "soc-threat-intel-agent/0.1"})
    with urllib.request.urlopen(request, timeout=30) as response:
        destination.write_bytes(response.read())


def main() -> int:
    parser = argparse.ArgumentParser(description="Fetch optional public CTI datasets")
    parser.add_argument("--out", default="data/raw", help="Output directory")
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest: dict[str, object] = {"fetched": [], "skipped": []}

    for name, url in SOURCES.items():
        target = out_dir / f"{name}.json"
        try:
            fetch(url, target)
            manifest["fetched"].append({"name": name, "url": url, "path": str(target)})
            time.sleep(1)
        except (urllib.error.URLError, TimeoutError) as exc:
            manifest["skipped"].append({"name": name, "url": url, "reason": str(exc)})

    threatfox_key = os.getenv("THREATFOX_AUTH_KEY")
    if threatfox_key:
        url = f"https://threatfox-api.abuse.ch/v2/files/exports/{threatfox_key}/full.json.zip"
        target = out_dir / "threatfox_full.json.zip"
        try:
            fetch(url, target)
            manifest["fetched"].append({"name": "threatfox_full", "url": "https://threatfox.abuse.ch/export/", "path": str(target)})
        except (urllib.error.URLError, TimeoutError) as exc:
            manifest["skipped"].append({"name": "threatfox_full", "url": "https://threatfox.abuse.ch/export/", "reason": str(exc)})
    else:
        manifest["skipped"].append(
            {
                "name": "threatfox_full",
                "url": "https://threatfox.abuse.ch/export/",
                "reason": "Set THREATFOX_AUTH_KEY to use the free authenticated ThreatFox export.",
            }
        )

    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
