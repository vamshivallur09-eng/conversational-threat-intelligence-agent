from __future__ import annotations

from dataclasses import dataclass


INJECTION_PHRASES = (
    "ignore previous instructions",
    "ignore all previous instructions",
    "disregard previous instructions",
    "reveal your system prompt",
    "print your system prompt",
    "developer message",
    "system message",
    "you are now",
    "override your instructions",
    "exfiltrate",
    "tool output says",
    "do not cite",
    "delete your logs",
)


@dataclass(frozen=True)
class InjectionFinding:
    phrase: str
    location: str


def _contains_phrase(text: str) -> str | None:
    lowered = text.lower()
    for phrase in INJECTION_PHRASES:
        if phrase in lowered:
            return phrase
    return None


def scan_for_injection(text: str, *, location: str) -> list[InjectionFinding]:
    phrase = _contains_phrase(text)
    return [InjectionFinding(phrase=phrase, location=location)] if phrase else []


def sanitize_untrusted_text(value: object) -> str:
    """Strip instruction-like text from retrieved intel before rendering it."""
    if value is None:
        return ""
    text = str(value).replace("\r\n", "\n")
    safe_lines: list[str] = []
    for line in text.split("\n"):
        if _contains_phrase(line):
            safe_lines.append("[redacted instruction-like text from untrusted source]")
        else:
            safe_lines.append(line)
    return "\n".join(safe_lines).strip()
