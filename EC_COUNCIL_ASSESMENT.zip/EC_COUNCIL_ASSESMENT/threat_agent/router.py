from __future__ import annotations

import ipaddress
import re

from .dataset import IntelDataset
from .models import AgentContext, Route


IP_CANDIDATE_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
HASH_RE = re.compile(r"\b[a-fA-F0-9]{32}\b|\b[a-fA-F0-9]{40}\b|\b[a-fA-F0-9]{64}\b")
DOMAIN_RE = re.compile(
    r"\b(?!(?:cve|ttp)\b)(?:[a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,63}\b"
)
PRODUCT_VERSION_RE = re.compile(
    r"\b(?P<product>confluence|atlassian confluence|log4j|apache log4j|exchange)\s+"
    r"(?P<version>\d+(?:\.\d+){0,3})\b",
    re.IGNORECASE,
)


def extract_ip(text: str) -> str | None:
    for candidate in IP_CANDIDATE_RE.findall(text):
        try:
            ipaddress.ip_address(candidate)
        except ValueError:
            continue
        return candidate
    return None


def extract_hash(text: str) -> str | None:
    match = HASH_RE.search(text)
    return match.group(0).lower() if match else None


def extract_domain(text: str) -> str | None:
    for candidate in DOMAIN_RE.findall(text):
        if not candidate.lower().startswith(("www.", "http.")):
            return candidate.lower()
    return None


def extract_ioc(text: str) -> tuple[str, str] | tuple[None, None]:
    if ip := extract_ip(text):
        return ip, "ip"
    if file_hash := extract_hash(text):
        return file_hash, "hash"
    if domain := extract_domain(text):
        return domain, "domain"
    return None, None


def route_message(message: str, context: AgentContext, dataset: IntelDataset) -> Route:
    lowered = message.lower()
    indicator, indicator_type = extract_ioc(message)

    if "help" in lowered or lowered.strip() in {"?", "examples"}:
        return Route(intent="help")

    if any(word in lowered for word in ("pivot", "related", "domains", "infrastructure")):
        if indicator:
            return Route("pivot", {"indicator": indicator, "indicator_type": indicator_type or ""})
        if context.last_indicator and any(token in lowered for token in ("that", "it", "this", "previous")):
            return Route(
                "pivot",
                {
                    "indicator": context.last_indicator,
                    "indicator_type": context.last_indicator_type or "",
                },
            )

    if "asn" in lowered and context.last_indicator:
        return Route(
            "ioc_lookup",
            {
                "indicator": context.last_indicator,
                "indicator_type": context.last_indicator_type or "",
            },
            requested_field="asn",
        )

    product_match = PRODUCT_VERSION_RE.search(message)
    if product_match and any(word in lowered for word in ("exposed", "vulnerable", "risk", "cve", "run")):
        product = product_match.group("product").lower().replace("atlassian ", "")
        return Route(
            "exposure_lookup",
            {"product": product, "version": product_match.group("version")},
        )

    if actor_names := dataset.actor_names_in_text(message):
        if any(word in lowered for word in ("ttp", "ttps", "technique", "actor", "known for", "profile")):
            return Route("actor_profile", {"actor": actor_names[0]})

    if indicator:
        return Route("ioc_lookup", {"indicator": indicator, "indicator_type": indicator_type or ""})

    if any(token in lowered for token in ("it", "that", "this")) and context.last_indicator:
        return Route(
            "ioc_lookup",
            {
                "indicator": context.last_indicator,
                "indicator_type": context.last_indicator_type or "",
            },
        )

    return Route("unknown")
