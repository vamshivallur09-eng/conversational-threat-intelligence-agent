from __future__ import annotations

import argparse
import sys

from .dataset import DEFAULT_DATA_PATH
from .session import ThreatIntelAgent


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Conversational SOC threat intelligence agent")
    parser.add_argument("--data", default=str(DEFAULT_DATA_PATH), help="Path to seed dataset JSON")
    parser.add_argument("--ask", help="Run one question and exit")
    parser.add_argument("--trace", action="store_true", help="Show tool-routing trace")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    agent = ThreatIntelAgent(args.data, include_trace=args.trace)
    if args.ask:
        print(agent.ask(args.ask))
        return 0

    print("SOC Threat Intel Agent. Type 'help' for examples or 'exit' to quit.")
    while True:
        try:
            message = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if message.lower() in {"exit", "quit"}:
            return 0
        if not message:
            continue
        print(agent.ask(message))
        print()


if __name__ == "__main__":
    sys.exit(main())
