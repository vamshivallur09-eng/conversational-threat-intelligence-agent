from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Route:
    intent: str
    entities: dict[str, str] = field(default_factory=dict)
    requested_field: str | None = None


@dataclass
class AgentContext:
    last_indicator: str | None = None
    last_indicator_type: str | None = None
    last_actor: str | None = None
    last_product: str | None = None
    last_product_version: str | None = None
    last_entities: dict[str, str] = field(default_factory=dict)


@dataclass
class ToolResult:
    intent: str
    title: str
    verdict: str
    confidence: float
    details: list[str]
    evidence: list[dict[str, Any]]
    entities: dict[str, str] = field(default_factory=dict)
    trace: list[str] = field(default_factory=list)
