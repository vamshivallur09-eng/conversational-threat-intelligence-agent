from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


DEFAULT_DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "threat_intel_seed.json"


def normalize_indicator(value: str) -> str:
    return value.strip().lower().strip(".,;:!?")


def parse_version(value: str) -> tuple[int, ...]:
    parts = re.findall(r"\d+", value)
    if not parts:
        return (0,)
    return tuple(int(part) for part in parts)


def compare_versions(left: str, right: str) -> int:
    lhs = list(parse_version(left))
    rhs = list(parse_version(right))
    width = max(len(lhs), len(rhs), 3)
    lhs.extend([0] * (width - len(lhs)))
    rhs.extend([0] * (width - len(rhs)))
    if lhs < rhs:
        return -1
    if lhs > rhs:
        return 1
    return 0


def version_in_range(version: str, range_spec: dict[str, str]) -> bool:
    lower = range_spec.get("from")
    upper = range_spec.get("before")
    if lower and compare_versions(version, lower) < 0:
        return False
    if upper and compare_versions(version, upper) >= 0:
        return False
    return True


class IntelDataset:
    def __init__(self, path: str | Path = DEFAULT_DATA_PATH):
        self.path = Path(path)
        with self.path.open("r", encoding="utf-8") as handle:
            self.data: dict[str, Any] = json.load(handle)

        self.iocs = {
            normalize_indicator(item["indicator"]): item
            for item in self.data.get("iocs", [])
        }
        self.actor_aliases: dict[str, dict[str, Any]] = {}
        for actor in self.data.get("actors", []):
            names = [actor["name"], *actor.get("aliases", [])]
            for name in names:
                self.actor_aliases[name.lower()] = actor

    def find_ioc(self, indicator: str) -> dict[str, Any] | None:
        return self.iocs.get(normalize_indicator(indicator))

    def find_actor(self, name: str) -> dict[str, Any] | None:
        return self.actor_aliases.get(name.lower().strip())

    def actor_names_in_text(self, text: str) -> list[str]:
        lowered = text.lower()
        names = sorted(self.actor_aliases, key=len, reverse=True)
        return [name for name in names if re.search(rf"\b{re.escape(name)}\b", lowered)]

    def find_exposures(self, product: str, version: str) -> list[dict[str, Any]]:
        product_key = product.lower().strip()
        matches: list[dict[str, Any]] = []
        for vuln in self.data.get("vulnerabilities", []):
            aliases = [vuln.get("product", ""), *vuln.get("product_aliases", [])]
            if product_key not in [alias.lower() for alias in aliases]:
                continue
            if any(version_in_range(version, item) for item in vuln.get("affected_ranges", [])):
                matches.append(vuln)
        return matches

    def pivot(self, indicator: str) -> dict[str, Any] | None:
        item = self.find_ioc(indicator)
        if not item:
            return None
        related = item.get("related", {})
        return {
            "indicator": item["indicator"],
            "indicator_type": item["type"],
            "related": related,
            "evidence": item.get("evidence", []),
        }
