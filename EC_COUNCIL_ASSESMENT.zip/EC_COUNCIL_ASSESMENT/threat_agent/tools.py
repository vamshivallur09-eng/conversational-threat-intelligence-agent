from __future__ import annotations

from typing import Any

from .dataset import IntelDataset
from .models import ToolResult
from .security import sanitize_untrusted_text


def _confidence(value: object, default: float = 0.5) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return default


def lookup_ioc(
    dataset: IntelDataset, indicator: str, indicator_type: str = "", requested_field: str | None = None
) -> ToolResult:
    item = dataset.find_ioc(indicator)
    trace = [f"tool=ioc_lookup indicator={indicator}"]
    if not item:
        return ToolResult(
            intent="ioc_lookup",
            title=f"IOC lookup: {indicator}",
            verdict="unknown",
            confidence=0.2,
            details=[
                "No matching record was found in the local seed dataset.",
                "Do not treat this as a clean verdict; query a live reputation source before enforcement.",
            ],
            evidence=[],
            entities={"indicator": indicator, "indicator_type": indicator_type},
            trace=trace,
        )

    details: list[str] = []
    if requested_field == "asn" and item.get("asn"):
        details.append(f"ASN: {sanitize_untrusted_text(item['asn'])}")
    else:
        details.extend(
            [
                f"Type: {sanitize_untrusted_text(item.get('type', indicator_type))}",
                f"Tags: {', '.join(item.get('tags', [])) or 'none'}",
            ]
        )
        if item.get("asn"):
            details.append(f"ASN: {sanitize_untrusted_text(item['asn'])}")
        if item.get("country"):
            details.append(f"Country: {sanitize_untrusted_text(item['country'])}")
        if item.get("note"):
            details.append(sanitize_untrusted_text(item["note"]))

    return ToolResult(
        intent="ioc_lookup",
        title=f"IOC lookup: {item['indicator']}",
        verdict=sanitize_untrusted_text(item.get("verdict", "unknown")),
        confidence=_confidence(item.get("confidence")),
        details=details,
        evidence=item.get("evidence", []),
        entities={"indicator": item["indicator"], "indicator_type": item.get("type", indicator_type)},
        trace=trace,
    )


def profile_actor(dataset: IntelDataset, actor_name: str) -> ToolResult:
    actor = dataset.find_actor(actor_name)
    trace = [f"tool=actor_profile actor={actor_name}"]
    if not actor:
        return ToolResult(
            intent="actor_profile",
            title=f"Actor profile: {actor_name}",
            verdict="unknown",
            confidence=0.2,
            details=["No actor record matched the local ATT&CK-derived seed data."],
            evidence=[],
            entities={"actor": actor_name},
            trace=trace,
        )

    techniques = actor.get("techniques", [])
    top_techniques = [
        f"{item['id']} {sanitize_untrusted_text(item['name'])}: {sanitize_untrusted_text(item['use'])}"
        for item in techniques[:8]
    ]
    details = [
        f"Aliases: {', '.join(actor.get('aliases', []))}",
        sanitize_untrusted_text(actor.get("summary", "")),
        "Representative TTPs:",
        *top_techniques,
    ]

    return ToolResult(
        intent="actor_profile",
        title=f"Actor profile: {actor['name']}",
        verdict="known threat actor",
        confidence=_confidence(actor.get("confidence"), 0.85),
        details=details,
        evidence=actor.get("evidence", []),
        entities={"actor": actor["name"]},
        trace=trace,
    )


def lookup_exposure(dataset: IntelDataset, product: str, version: str) -> ToolResult:
    findings = dataset.find_exposures(product, version)
    trace = [f"tool=exposure_lookup product={product} version={version}"]
    if not findings:
        return ToolResult(
            intent="exposure_lookup",
            title=f"Exposure lookup: {product} {version}",
            verdict="no matching exposure in seed data",
            confidence=0.55,
            details=[
                "The local seed data did not match this version to a known affected range.",
                "This is not a complete vulnerability scan; check NVD, vendor advisories, and CISA KEV.",
            ],
            evidence=[],
            entities={"product": product, "version": version},
            trace=trace,
        )

    evidence: list[dict[str, Any]] = []
    details: list[str] = []
    max_confidence = 0.0
    for finding in findings:
        max_confidence = max(max_confidence, _confidence(finding.get("confidence"), 0.85))
        details.append(
            f"{finding['cve']} ({finding['severity']}, CVSS {finding.get('cvss', 'n/a')}): "
            f"{sanitize_untrusted_text(finding['name'])}"
        )
        details.append(f"Exposure reason: {sanitize_untrusted_text(finding['exposure_reason'])}")
        details.append(f"Fixed versions: {', '.join(finding.get('fixed_versions', []))}")
        if finding.get("known_exploited"):
            details.append("CISA KEV: yes")
        evidence.extend(finding.get("evidence", []))

    return ToolResult(
        intent="exposure_lookup",
        title=f"Exposure lookup: {product} {version}",
        verdict="exposed",
        confidence=max_confidence,
        details=details,
        evidence=evidence,
        entities={"product": product, "version": version},
        trace=trace,
    )


def pivot_indicator(dataset: IntelDataset, indicator: str, indicator_type: str = "") -> ToolResult:
    pivot = dataset.pivot(indicator)
    trace = [f"tool=pivot indicator={indicator}"]
    if not pivot:
        return ToolResult(
            intent="pivot",
            title=f"Pivot: {indicator}",
            verdict="no related entities found",
            confidence=0.35,
            details=["No relationship data exists for this indicator in the local seed dataset."],
            evidence=[],
            entities={"indicator": indicator, "indicator_type": indicator_type},
            trace=trace,
        )

    related = pivot.get("related", {})
    details: list[str] = []
    for key in ("domains", "ips", "hashes", "actors"):
        values = related.get(key, [])
        if values:
            details.append(f"{key.title()}: {', '.join(sanitize_untrusted_text(v) for v in values)}")
    if not details:
        details.append("The indicator exists, but no pivots are present in the seed record.")

    return ToolResult(
        intent="pivot",
        title=f"Pivot: {pivot['indicator']}",
        verdict="related entities found" if details else "no related entities found",
        confidence=0.7,
        details=details,
        evidence=pivot.get("evidence", []),
        entities={"indicator": pivot["indicator"], "indicator_type": pivot.get("indicator_type", indicator_type)},
        trace=trace,
    )
