from __future__ import annotations

from pathlib import Path

from .dataset import DEFAULT_DATA_PATH, IntelDataset
from .models import AgentContext, ToolResult
from .router import extract_ioc, route_message
from .security import sanitize_untrusted_text, scan_for_injection
from .tools import lookup_exposure, lookup_ioc, pivot_indicator, profile_actor


class ThreatIntelAgent:
    def __init__(self, data_path: str | Path = DEFAULT_DATA_PATH, *, include_trace: bool = False):
        self.dataset = IntelDataset(data_path)
        self.context = AgentContext()
        self.include_trace = include_trace

    def ask(self, message: str) -> str:
        direct_findings = scan_for_injection(message, location="user_message")
        route = route_message(message, self.context, self.dataset)
        safety_note = ""
        if direct_findings:
            safety_note = (
                "Safety: prompt-injection language was detected in the user message. "
                "Instruction-like text was ignored; only the threat-intel request was processed.\n\n"
            )
            if route.intent == "unknown" and not extract_ioc(message)[0]:
                return safety_note + "No actionable threat-intel entity was found."

        if route.intent == "help":
            return self._help()
        if route.intent == "ioc_lookup":
            result = lookup_ioc(
                self.dataset,
                route.entities["indicator"],
                route.entities.get("indicator_type", ""),
                route.requested_field,
            )
        elif route.intent == "actor_profile":
            result = profile_actor(self.dataset, route.entities["actor"])
        elif route.intent == "exposure_lookup":
            result = lookup_exposure(
                self.dataset, route.entities["product"], route.entities["version"]
            )
        elif route.intent == "pivot":
            result = pivot_indicator(
                self.dataset,
                route.entities["indicator"],
                route.entities.get("indicator_type", ""),
            )
        else:
            return safety_note + self._unknown()

        self._remember(result)
        return safety_note + self._format_result(result)

    def _remember(self, result: ToolResult) -> None:
        if indicator := result.entities.get("indicator"):
            self.context.last_indicator = indicator
            self.context.last_indicator_type = result.entities.get("indicator_type")
        if actor := result.entities.get("actor"):
            self.context.last_actor = actor
        if product := result.entities.get("product"):
            self.context.last_product = product
            self.context.last_product_version = result.entities.get("version")
        self.context.last_entities = result.entities

    def _format_result(self, result: ToolResult) -> str:
        lines = [
            result.title,
            f"Intent: {result.intent}",
            f"Verdict: {result.verdict}",
            f"Confidence: {round(result.confidence * 100)}%",
            "",
            "Details:",
        ]
        lines.extend(f"- {sanitize_untrusted_text(item)}" for item in result.details)
        if result.evidence:
            lines.extend(["", "Evidence:"])
            for item in result.evidence:
                source = sanitize_untrusted_text(item.get("source", "unknown source"))
                summary = sanitize_untrusted_text(item.get("summary", ""))
                url = sanitize_untrusted_text(item.get("url", ""))
                observed = sanitize_untrusted_text(item.get("observed", ""))
                suffix = f" ({observed})" if observed else ""
                lines.append(f"- {source}{suffix}: {summary}")
                if url:
                    lines.append(f"  {url}")
        else:
            lines.extend(["", "Evidence:", "- No source-backed record was available."])
        if self.include_trace and result.trace:
            lines.extend(["", "Trace:"])
            lines.extend(f"- {step}" for step in result.trace)
        return "\n".join(lines)

    def _help(self) -> str:
        return (
            "Ask about an IOC, actor, exposure, or pivot.\n"
            "Examples:\n"
            "- Is 45.83.122.10 malicious?\n"
            "- and what's its ASN?\n"
            "- What TTPs is APT29 known for?\n"
            "- We run Confluence 7.13 - are we exposed?\n"
            "- Pivot from that IP to related domains."
        )

    def _unknown(self) -> str:
        return (
            "I could not route that request. Try an IP, domain, file hash, actor name, "
            "or product/version question. Type 'help' for examples."
        )
